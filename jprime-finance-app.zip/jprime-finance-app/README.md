
# JPrime Finance App

npm install
npm run dev
